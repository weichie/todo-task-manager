# todo-task-manager
A todo-task manager in a nice dashboard layout written with PHP.

Using:
 - Twitter Bootstrap
 - OOP
 - XSS and SQL injection protections
 - MySQL database
 - There were no php frameworks used
 - Added success or error messages
 - errors are catched with 'try-catch' structures
