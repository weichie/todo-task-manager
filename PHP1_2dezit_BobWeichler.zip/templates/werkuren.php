<div class="page flexbox">
	<div class="sidebar">
		<?php include_once('sidebar.php'); ?>
	</div><!-- ./sidebar -->
	
	<div class="content">
		<header class="flexbox">
			<?php include_once('navbar.php'); ?>
		</header>
		<div class="flexbox werkuren">
			<h3>Werkuren deze week:</h3>

			
		</div><!-- ./flexbox -->
	</div><!-- ./content -->
</div><!-- ./page -->