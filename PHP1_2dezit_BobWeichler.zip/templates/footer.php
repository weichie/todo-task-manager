	<!-- Scriptzz -->
	<script src="assets/js/jquery-v1.12.4.min.js"></script>
	<script src="assets/js/bootstrap.min.js"></script>
	<script src="assets/js/custom.js"></script>
</body>
</html>